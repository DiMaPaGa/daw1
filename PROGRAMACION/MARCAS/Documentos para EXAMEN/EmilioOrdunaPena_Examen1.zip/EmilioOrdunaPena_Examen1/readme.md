# Emilio Orduña Peña

## EXAMEN 1


---

### **General**

Me hubiera gustado mucho hacer una web más completa, detallada y personalizada. Aunque incluya todos los contenidos no estoy contento al 100% con el resultado

***

### **Información sobre uso**

* Menú de navegación con las categorías
    + Home
    + Blog
    + Portfolio
    + Services
    + About
    + About me
    + Contact

**(Todas ellas con sus respectivas páginas)**

--- 

